#!/usr/bin/env python3
"""
Simple Usage Example: Direct InterHub to RDS-HQ Conversion

This script demonstrates the simplest way to use the InterHub-TeraSim bridge
to generate RDS-HQ data directly from InterHub's unified cache.

Before running this script:
1. Install InterHub and run data unification to create the unified cache
2. Install TeraSim and ensure terasim-cosmos is available
3. Optionally run InterHub's interaction extraction for batch processing
4. Update the paths below to match your directory structure
"""

from pathlib import Path
from interhub_terasim_bridge import InterHubToTeraSimBridge


# ==============================================================================
# Configuration - Update these paths for your setup
# ==============================================================================

# Resolve project root and subfolders based on current file location
ROOT_DIR = Path(__file__).resolve().parent
INTERHUB_ROOT = ROOT_DIR / "InterHub"
TERASIM_ROOT = ROOT_DIR / "TeraSim"

# Path to InterHub's unified cache directory
# This is created by running: python 0_data_unify.py (inside InterHub/)
INTERHUB_CACHE = "/mnt/e/intersim/interhub/data/1_unified_cache"

# Dataset name in the cache
DATASET_NAME = "interaction_multi"

# Path to InterHub's interaction extraction results (optional, for batch mode)
# This is created by running: python 1_interaction_extract.py (inside InterHub/)
INTERACTION_CSV = INTERHUB_ROOT / "data" / "2_extracted_results" / "results.csv"

# Where to save all RDS-HQ outputs (inside TeraSim/outputs)
OUTPUT_DIR = TERASIM_ROOT / "outputs" / "rds_hq_results"


# ==============================================================================
# Example 1: Convert a Single Scene
# ==============================================================================

def example_single_scene():
    """
    Convert a single scene from InterHub to RDS-HQ format.
    
    This example shows the minimum required configuration to generate RDS-HQ
    data for one scene and a specific time interval. It is ideal for quick
    prototyping and debugging the conversion pipeline.
    """
    print("\n" + "="*70)
    print("Example 1: Single Scene Conversion")
    print("="*70 + "\n")
    SUMO_DEMO_NET = "/mnt/e/intersim/sumo_nets/hello.net.xml"
    # Initialize the bridge
    bridge = InterHubToTeraSimBridge(
        interhub_cache_path=INTERHUB_CACHE,
        dataset_name=DATASET_NAME,
        verbose=True,
        sumo_net_path=SUMO_DEMO_NET,
    )
    
    # Generate RDS-HQ for a specific scene and time window
    output_path = bridge.generate_rds_hq_from_scene(
        scene_idx=10,              # Which scene from the dataset
        time_start=0.0,            # Start at 5 seconds into the scene
        time_end=3.5,             # End at 15 seconds into the scene
        output_dir=OUTPUT_DIR / "example_1_single_scene",
        ego_agent_id=None,         # Auto-select most relevant ego if None
        streetview_retrieval=False # Disable external StreetView retrieval
    )
    
    print(f"\n✓ RDS-HQ data generated at: {output_path}")
    print("This directory can now be used with NVIDIA Cosmos-Drive!")


# ==============================================================================
# Example 2: Batch Process Multiple Interactions
# ==============================================================================

def example_batch_interactions():
    """
    Process multiple interaction scenarios identified by InterHub.
    
    This leverages InterHub's sophisticated interaction detection to focus
    on the most interesting segments of the data. Rather than converting
    entire hours of driving, we only process the interaction-rich segments.
    """
    print("\n" + "="*70)
    print("Example 2: Batch Interaction Processing")
    print("="*70 + "\n")
    
    bridge = InterHubToTeraSimBridge(
        interhub_cache_path=INTERHUB_CACHE,
        dataset_name=DATASET_NAME
    )
    
    # The bridge provides a convenience method for batch processing
    output_paths = bridge.batch_process_interactions(
        interaction_csv_path=INTERACTION_CSV,
        output_root_dir=OUTPUT_DIR / "example_2_batch_interactions",
        max_interactions=10,
        streetview_retrieval=False
    )
    
    print("\n✓ Batch processing complete!")
    print(f"Generated {len(output_paths)} RDS-HQ interaction clips:")
    for p in output_paths:
        print(f"  - {p}")


# ==============================================================================
# Example 3: Explore Available Scenes
# ==============================================================================

def example_explore_scenes():
    """
    Print basic information about available scenes in the InterHub dataset.
    
    This is useful for understanding how many scenes are available, how long
    they are, and what types of interactions they contain before deciding
    which ones to convert to RDS-HQ.
    """
    print("\n" + "="*70)
    print("Example 3: Explore InterHub Scenes")
    print("="*70 + "\n")
    
    bridge = InterHubToTeraSimBridge(
        interhub_cache_path=INTERHUB_CACHE,
        dataset_name=DATASET_NAME
    )
    
    print(f"Dataset contains {len(bridge.dataset)} scenes.\n")
    
    # Show first few scenes as a preview
    num_preview = min(5, len(bridge.dataset))
    for scene_idx in range(num_preview):
        info = bridge.get_scene_summary(scene_idx)
        print(f"Scene {scene_idx:03d}:")
        print(f"  Name      : {info['name']}")
        print(f"  Duration  : {info['duration_sec']:.1f} seconds")
        print(f"  Num agents: {info['num_agents']}")
        print(f"  Location  : {info['location']}")
        print()


# ==============================================================================
# Example 4: Convenience Function Usage
# ==============================================================================

def example_convenience_function():
    """
    Demonstrate the top-level convenience function for one-shot conversion.
    
    This is the most compact way to perform a conversion when you already
    know which scene and time window you want to process.
    """
    print("\n" + "="*70)
    print("Example 4: Convenience Function Conversion")
    print("="*70 + "\n")
    
    from interhub_terasim_bridge import convert_interhub_scene_to_rds_hq
    
    output_path = convert_interhub_scene_to_rds_hq(
        cache_path=INTERHUB_CACHE,
        scene_idx=15,
        time_start=0.0,
        time_end=3.5,
        output_dir=OUTPUT_DIR / "example_4_convenience",
        dataset_name=DATASET_NAME
    )
    
    print(f"\n✓ RDS-HQ data generated at: {output_path}")


# ==============================================================================
# Main Entrypoint
# ==============================================================================

def main():
    """
    Run all usage examples with basic error handling.
    
    This function orchestrates the examples and provides clear guidance if
    required data (like the InterHub cache or interaction CSV) is missing.
    """
    import sys
    
    print("\n" + "="*70)
    print("InterHub to TeraSim Direct Integration Examples")
    print("="*70)
    
    # Check if required paths exist
    # Path imported at top-level
    
    if not Path(INTERHUB_CACHE).exists():
        print(f"\n⚠ Error: InterHub cache not found at: {INTERHUB_CACHE}")
        print("Please run InterHub's data unification first:")
        print("  python 0_data_unify.py --desired_data interaction_multi \\")
        print("                         --load_path data/0_origin_datasets/interaction_multi \\")
        print("                         --save_path data/1_unified_cache")
        sys.exit(1)
    
    try:
        # Run example 1: Single scene conversion
        example_single_scene()
        
        # Run example 3: Explore scenes (doesn't require interaction CSV)
        example_explore_scenes()
        
        # Run example 4: Convenience function usage
        example_convenience_function()
        
        # Run example 2: Batch processing (only if interaction CSV exists)
        if Path(INTERACTION_CSV).exists():
            example_batch_interactions()
        else:
            print(f"\n⚠ Skipping batch example: {INTERACTION_CSV} not found")
            print("Run InterHub's interaction extraction to enable batch processing:")
            print("  python 1_interaction_extract.py --desired_data interaction_multi \\")
            print("                                  --cache_location data/1_unified_cache \\")
            print("                                  --save_path data/2_extracted_results")
        
        print("\n" + "="*70)
        print("✓ All Examples Complete!")
        print("="*70)
        print("\nThe generated RDS-HQ data can now be used with NVIDIA Cosmos-Drive")
        print("for training generative models and synthesizing sensor data.")
        
    except Exception as e:
        print(f"\n⚠ Error running examples: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
