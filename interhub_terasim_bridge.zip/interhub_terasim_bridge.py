"""
InterHub-TeraSim Direct Integration Bridge

This module provides a seamless bridge between InterHub's trajectory data and
TeraSim's RDS-HQ generation capabilities, allowing direct conversion from
InterHub's unified cache to Cosmos-Drive compatible format.
"""

import os
import numpy as np
import pandas as pd
import xml.etree.ElementTree as ET
from xml.dom import minidom
from pathlib import Path
from typing import Optional, Dict, List, Union, Tuple
from tqdm import tqdm

# InterHub / trajdata dependencies
from trajdata.data_structures import Scene
from trajdata.caching import EnvCache
from trajdata.caching.df_cache import DataFrameCache
from trajdata.data_structures import AgentType

# TeraSim dependencies
from terasim_cosmos import TeraSimToCosmosConverter


class InterHubToTeraSimBridge:
    """
    Bridge between InterHub's unified trajectory data and TeraSim's RDS-HQ
    generation pipeline.

    这里不再使用 UnifiedDataset，而是直接用 EnvCache + DataFrameCache
    从 InterHub 的 unified cache 里读场景，再生成 SUMO FCD，然后调用
    TeraSim 的 TeraSimToCosmosConverter。
    """

    def __init__(
        self,
        interhub_cache_path: Union[str, Path],
        dataset_name: str = "interaction_multi",
        verbose: bool = True,
        scene_dt: float = 0.1,
        sumo_net_path: Optional[Union[str, Path]] = None,  
    ):
        """
        Args:
            interhub_cache_path: InterHub 的 unified cache 根目录
                （例如 /mnt/e/intersim/interhub/data/1_unified_cache）
            dataset_name: env 名（对应子目录名），例如 "interaction_multi"
            scene_dt: 场景时间步长（秒），InterHub 默认 0.1
        """
        self.cache_path = Path(interhub_cache_path).resolve()
        self.env_name = dataset_name
        self.verbose = verbose
        self.scene_dt = scene_dt
        self.sumo_net_path = Path(sumo_net_path).resolve() if sumo_net_path is not None else None

        if not self.cache_path.exists():
            raise FileNotFoundError(
                f"InterHub cache not found at: {self.cache_path}\n"
                f"请确认 0_data_unify.py 已经生成 data/1_unified_cache。"
            )

        if self.verbose:
            print(f"[Bridge] Loading InterHub dataset from: {self.cache_path}")
            print(f"[Bridge] Env name: {self.env_name}")

        try:
            # 使用 EnvCache 直接读 unified cache
            self.env_cache = EnvCache(self.cache_path)
            self.scenes_list = self.env_cache.load_env_scenes_list(self.env_name)
            self.num_scenes = len(self.scenes_list)

            if self.verbose:
                print(
                    f"✓ Successfully loaded {self.num_scenes} scenes "
                    f"from env '{self.env_name}'"
                )
        except Exception as e:
            raise ValueError(
                f"Failed to load scenes from EnvCache: {e}\n"
                f"请确认路径 {self.cache_path}/{self.env_name} 下存在 scenes_list.dill。"
            )

    # ------------------------------------------------------------------
    # 对外主接口：单场景转换
    # ------------------------------------------------------------------
    def generate_rds_hq_from_scene(
        self,
        scene_idx: int,
        time_start: float,
        time_end: float,
        output_dir: Union[str, Path],
        ego_agent_id: Optional[str] = None,
        streetview_retrieval: bool = False,
        agent_clip_distance: float = 80.0,
        map_clip_distance: float = 100.0,
        camera_setting: str = "default",
    ) -> Path:
        """
        从一个 InterHub 场景直接生成 RDS-HQ。

        Args:
            scene_idx: 场景索引（0 ~ num_scenes-1）
            time_start: 起始时间（秒）
            time_end: 结束时间（秒）
            output_dir: 输出根目录
            ego_agent_id: 可选，指定 ego 车的 agent name；None 则自动选择
            streetview_retrieval: 是否启用街景抓取
            agent_clip_distance: 只保留距离 ego 车该半径内的其他 agent
            map_clip_distance: RDS-HQ 中地图裁剪距离
            camera_setting: 相机配置预设（对应 TeraSim 的 camera_setting_name）
        """
        if scene_idx < 0 or scene_idx >= self.num_scenes:
            raise ValueError(
                f"Scene index {scene_idx} out of bounds. "
                f"Env has {self.num_scenes} scenes (0 ~ {self.num_scenes-1})"
            )

        if time_end <= time_start:
            raise ValueError(
                f"Invalid time window: end time ({time_end}) "
                f"must be greater than start time ({time_start})"
            )

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        fcd_dir = output_path / "fcd"
        map_dir = output_path / "maps"
        rds_base_dir = output_path / "rds_hq"  # 作为 TeraSim path_to_output 的基目录

        for d in (fcd_dir, map_dir, rds_base_dir):
            d.mkdir(parents=True, exist_ok=True)

        # ===== STEP 1: 从 EnvCache 取出 Scene =====
        if self.verbose:
            print("\n" + "=" * 70)
            print("STEP 1/4: Extracting Scene Data from InterHub")
            print("=" * 70)

        scene_tag = self.scenes_list[scene_idx]
        scene_name = getattr(scene_tag, "name", f"scene_{scene_idx}")

        scene: Scene = self.env_cache.load_scene(
            self.env_name, scene_name, scene_dt=self.scene_dt
        )

        if self.verbose:
            print(f"[Bridge] Scene index: {scene_idx}")
            print(f"[Bridge] Scene name:  {scene.name}")
            print(f"[Bridge] Scene dt:    {scene.dt}")
            scene_duration = scene.length_timesteps * scene.dt
            print(
                f"[Bridge] Scene duration: "
                f"{scene_duration:.2f} s "
                f"({scene.length_timesteps} steps)"
            )
            print(
                f"[Bridge] Requested time window:   "
                f"[{time_start:.2f}, {time_end:.2f}] s"
            )

        # 简单裁剪一下时间窗口到场景长度内
        scene_duration = scene.length_timesteps * scene.dt
        orig_start, orig_end = time_start, time_end
        time_start = max(0.0, time_start)
        time_end = min(time_end, scene_duration)
        if time_end <= time_start:
            if self.verbose:
                print(
                    f"[Bridge] WARNING: requested window [{orig_start:.2f}, {orig_end:.2f}] "
                    f"outside scene duration [0.00, {scene_duration:.2f}]. "
                    f"Using full scene instead."
                )
            time_start = 0.0
            time_end = scene_duration

        if self.verbose:
            print(
                f"[Bridge] Effective time window:   "
                f"[{time_start:.2f}, {time_end:.2f}] s"
            )

        # ===== STEP 2: 生成 SUMO FCD =====
        if self.verbose:
            print("\n" + "=" * 70)
            print("STEP 2/4: Generating SUMO FCD File")
            print("=" * 70)

        fcd_path, ego_used = self._generate_sumo_fcd(
            scene=scene,
            time_start=time_start,
            time_end=time_end,
            output_dir=fcd_dir,
            ego_agent_id=ego_agent_id,
            agent_clip_distance=agent_clip_distance,
        )

        if self.verbose:
            print(f"✓ FCD file created: {fcd_path}")
            print(f"  File size: {fcd_path.stat().st_size / 1024:.2f} KB")
            print(f"[Bridge] Ego agent used in FCD: {ego_used}")

        # ===== STEP 3: 生成或寻找 SUMO 地图 =====
        if self.verbose:
            print("\n" + "=" * 70)
            print("STEP 3/4: Creating SUMO Map File")
            print("=" * 70)

        map_path = self._create_map_for_scene(
            scene=scene,
            fcd_path=fcd_path,
            output_dir=map_dir,
        )

        if self.verbose:
            print(f"✓ Map file ready: {map_path}")

        # ===== STEP 4: 调 TeraSim 做 RDS-HQ =====
        if self.verbose:
            print("\n" + "=" * 70)
            print("STEP 4/4: Running TeraSim RDS-HQ Converter")
            print("=" * 70)

        # 根据 TeraSim 的 converter.py 真实接口构造 config_dict
        cosmos_config = {
            "path_to_output": str(rds_base_dir),
            "path_to_fcd": str(fcd_path),
            "path_to_map": str(map_path),
            "camera_setting_name": camera_setting,
            "vehicle_id": ego_used,  # 明确告诉它用哪个 vehicle
            "time_start": float(time_start),
            "time_end": float(time_end),
            "agent_clip_distance": float(agent_clip_distance),
            "map_clip_distance": float(map_clip_distance),
            "streetview_retrieval": bool(streetview_retrieval),
        }

        cosmos_converter = TeraSimToCosmosConverter(config_dict=cosmos_config)
        cosmos_converter.convert()

        final_rds_dir = cosmos_converter.path_to_output

        if self.verbose:
            print("\n✓ RDS-HQ generation complete!")
            print(f"Base output dir: {rds_base_dir}")
            print(f"Final clip dir:  {final_rds_dir}")

        return final_rds_dir

    # ------------------------------------------------------------------
    # STEP 2: 使用 DataFrameCache + agent_presence 生成 FCD
    # ------------------------------------------------------------------
    def _generate_sumo_fcd(
        self,
        scene: Scene,
        time_start: float,
        time_end: float,
        output_dir: Path,
        ego_agent_id: Optional[str],
        agent_clip_distance: float,
    ) -> Tuple[Path, str]:
        """
        用 InterHub 的 Scene + DataFrameCache 生成 SUMO FCD XML。

        返回:
            fcd_path: 生成的 FCD 文件路径
            ego_used: 实际使用的 ego agent 名字
        """
        dt = scene.dt
        start_idx = max(0, int(time_start / dt))
        end_idx = min(scene.length_timesteps, int(time_end / dt))

        if end_idx <= start_idx:
            raise ValueError(
                f"Time window [{time_start}, {time_end}] is empty after "
                f"discretization with dt={dt}"
            )

        scene_cache = DataFrameCache(
            cache_path=self.cache_path,  # 必须是 Path，而不是 str
            scene=scene,
        )
        col = scene_cache.column_dict
        x_idx = col["x"]
        y_idx = col["y"]
        heading_idx = col.get("heading", None)
        if heading_idx is None:
            for key in ["yaw", "theta", "phi"]:
                if key in col:
                    heading_idx = col[key]
                    break
        if heading_idx is None:
            heading_idx = 0  # 实在没有就当 0

        if ego_agent_id is None:
            ego_agent_id = self._select_ego_agent(scene, start_idx, end_idx)

        if self.verbose:
            print(f"[Bridge] Ego agent: {ego_agent_id}")
            print(f"[Bridge] Agent clip distance: {agent_clip_distance} m")

        fcd_root = ET.Element("fcd-export")
        last_ego_pos = None

        for t_idx in tqdm(
            range(start_idx, end_idx), disable=not self.verbose, desc="Writing FCD"
        ):
            timestamp = t_idx * dt
            timestep_elem = ET.SubElement(
                fcd_root,
                "timestep",
                time=f"{timestamp:.2f}",
            )

            agents_present = scene.agent_presence[t_idx]  # List[AgentMetadata]
            names_present = [a.name for a in agents_present]

            ego_pos = None
            if ego_agent_id in names_present:
                try:
                    ego_state = scene_cache.get_raw_state(
                        agent_id=ego_agent_id, scene_ts=t_idx
                    )
                    ego_pos = np.array(
                        [ego_state[x_idx], ego_state[y_idx]], dtype=float
                    )
                    last_ego_pos = ego_pos
                except Exception:
                    ego_pos = last_ego_pos
            else:
                ego_pos = last_ego_pos

            if ego_pos is None:
                continue

            for agent_meta in agents_present:
                agent_name = agent_meta.name

                try:
                    raw_state = scene_cache.get_raw_state(
                        agent_id=agent_name, scene_ts=t_idx
                    )
                except Exception:
                    continue

                pos = np.array(
                    [raw_state[x_idx], raw_state[y_idx]], dtype=float
                )
                rel_dist = np.linalg.norm(pos - ego_pos)
                if rel_dist > agent_clip_distance:
                    continue

                heading_val = float(raw_state[heading_idx])
                angle_deg = float(np.degrees(heading_val))

                ET.SubElement(
                    timestep_elem,
                    "vehicle",
                    id=str(agent_name),
                    x=f"{pos[0]:.2f}",
                    y=f"{pos[1]:.2f}",
                    angle=f"{angle_deg:.2f}",
                    type="passenger",
                )

        fcd_path = output_dir / f"{scene.name}_fcd.xml"
        rough_string = ET.tostring(fcd_root, "utf-8")
        reparsed = minidom.parseString(rough_string)
        pretty_xml = reparsed.toprettyxml(indent="  ")

        with open(fcd_path, "w", encoding="utf-8") as f:
            f.write(pretty_xml)

        return fcd_path, ego_agent_id

    # ------------------------------------------------------------------
    # STEP 3: 地图 —— 生成一个最小可用的 SUMO net（带 version 属性）
    # ------------------------------------------------------------------
    def _create_map_for_scene(
        self,
        scene: Scene,
        fcd_path: Path,
        output_dir: Path,
    ) -> Path:
        """
        创建或查找对应的 SUMO 地图。

        优先级：
        1) 如果用户在 Bridge 初始化时传入 sumo_net_path（建议指向 SUMO 自带 demo .net.xml），
           就直接 copy 那个文件到 output_dir 下作为 default_map.net.xml；
        2) 否则才退回到“极简直线” map（我们之前的做法）。
        """
        default_map_path = output_dir / "default_map.net.xml"

        # 情况 1：使用用户提供的 SUMO demo net
        if self.sumo_net_path is not None and self.sumo_net_path.exists():
            # 直接复制到默认路径，TeraSim 下游会用这个
            import shutil
            shutil.copy(self.sumo_net_path, default_map_path)
            if self.verbose:
                print(f"[Bridge] Using SUMO demo net: {self.sumo_net_path}")
            return default_map_path

        # 情况 2：没有提供 demo net，退回到“极简直线” map
        if self.verbose:
            print("[Bridge] No external SUMO net provided, using minimal synthetic net.")

        # === 以下是我们之前生成的简易路网，但加入 version 属性，避免报错 ===
        net_root = ET.Element("net", {"version": "1.16"})

        ET.SubElement(
            net_root,
            "location",
            {
                "netOffset": "0.00,0.00",
                "convBoundary": "0.00,0.00,100.00,0.00",
                "origBoundary": "0.00,0.00,100.00,0.00",
                "projParameter": "!",
            },
        )

        edge = ET.SubElement(
            net_root,
            "edge",
            {
                "id": "edge0",
                "from": "n0",
                "to": "n1",
            },
        )

        ET.SubElement(
            edge,
            "lane",
            {
                "id": "edge0_0",
                "index": "0",
                "speed": "13.89",
                "length": "100.00",
                "shape": "0.00,0.00 100.00,0.00",
            },
        )

        ET.SubElement(
            net_root,
            "junction",
            {
                "id": "n0",
                "type": "priority",
                "x": "0.00",
                "y": "0.00",
                "incLanes": "",
                "intLanes": "",
                "shape": "0.00,0.00",
            },
        )

        ET.SubElement(
            net_root,
            "junction",
            {
                "id": "n1",
                "type": "priority",
                "x": "100.00",
                "y": "0.00",
                "incLanes": "edge0_0",
                "intLanes": "",
                "shape": "100.00,0.00",
            },
        )

        rough_string = ET.tostring(net_root, "utf-8")
        reparsed = minidom.parseString(rough_string)
        pretty_xml = reparsed.toprettyxml(indent="  ")

        with open(default_map_path, "w", encoding="utf-8") as f:
            f.write(pretty_xml)

        return default_map_path


    # ------------------------------------------------------------------
    # ego 选择逻辑：基于 agent_presence 的名字交集
    # ------------------------------------------------------------------
    def _select_ego_agent(
        self,
        scene: Scene,
        start_idx: int,
        end_idx: int,
    ) -> str:
        """
        根据 scene.agent_presence 在时间窗口内出现情况选择 ego 车。

        - 先找在所有 time step 都存在的 agent；
        - 尽量优先 VEHICLE 类型；
        - 实在不行就拿第一个有的。
        """
        start_idx = max(0, start_idx)
        end_idx = min(end_idx, len(scene.agent_presence))

        if start_idx >= end_idx:
            start_idx = 0
            end_idx = min(1, len(scene.agent_presence))

        names_per_t: List[set] = []
        for t in range(start_idx, end_idx):
            agents_present = scene.agent_presence[t]
            names_per_t.append({a.name for a in agents_present})

        if not names_per_t:
            if hasattr(scene, "agents") and scene.agents:
                return scene.agents[0].name
            raise ValueError("Scene has no agents to select as ego.")

        common = (
            set.intersection(*names_per_t)
            if len(names_per_t) > 1
            else names_per_t[0]
        )

        name_to_agent = {}
        if hasattr(scene, "agents"):
            for a in scene.agents:
                name_to_agent[a.name] = a

        candidate_order: List[str] = list(common) if common else list(
            names_per_t[0]
        )

        for name in candidate_order:
            agent = name_to_agent.get(name)
            if agent is not None and getattr(agent, "agent_type", None) == AgentType.VEHICLE:
                return name

        if candidate_order:
            return candidate_order[0]

        if name_to_agent:
            return next(iter(name_to_agent.keys()))

        raise ValueError("No agents found to select as ego.")

    # ------------------------------------------------------------------
    # 其它辅助：批处理 & 场景信息
    # ------------------------------------------------------------------
    def batch_process_interactions(
        self,
        interaction_csv_path: Union[str, Path],
        output_base_dir: Union[str, Path],
        max_scenes: Optional[int] = None,
        **kwargs,
    ) -> List[Path]:
        """
        批量将 InterHub 的 interaction csv 里的场景转换为 RDS-HQ。
        """
        interaction_csv_path = Path(interaction_csv_path)
        output_base_dir = Path(output_base_dir)
        output_base_dir.mkdir(parents=True, exist_ok=True)

        df = pd.read_csv(interaction_csv_path)
        outputs: List[Path] = []

        for idx, row in df.iterrows():
            if max_scenes is not None and idx >= max_scenes:
                break

            scene_idx = int(row["scene_idx"])
            time_start = float(row["time_start"])
            time_end = float(row["time_end"])

            interaction_id = row.get("interaction_id", f"interaction_{idx:04d}")
            interaction_dir = output_base_dir / interaction_id

            if self.verbose:
                print(f"\nProcessing interaction {interaction_id}:")
                print(f"  Scene index: {scene_idx}")
                print(f"  Time window: [{time_start:.2f}, {time_end:.2f}]")
                print(f"  Output dir:  {interaction_dir}")

            try:
                rds_path = self.generate_rds_hq_from_scene(
                    scene_idx=scene_idx,
                    time_start=time_start,
                    time_end=time_end,
                    output_dir=interaction_dir,
                    **kwargs,
                )
                outputs.append(rds_path)
            except Exception as e:
                print(f"⚠ Failed to process interaction {interaction_id}: {e}")

        return outputs

    def get_scene_info(self, scene_idx: int) -> Dict:
        """
        查询某个 scene 的简单信息（名字、时长、agent 数量等）
        """
        if scene_idx < 0 or scene_idx >= self.num_scenes:
            raise ValueError(f"Scene index {scene_idx} out of bounds")

        scene_tag = self.scenes_list[scene_idx]
        scene = self.env_cache.load_scene(
            self.env_name,
            getattr(scene_tag, "name", f"scene_{scene_idx}"),
            scene_dt=self.scene_dt,
        )

        agent_type_counts: Dict[str, int] = {}
        if hasattr(scene, "agents"):
            for a in scene.agents:
                atype = getattr(a, "agent_type", None)
                if isinstance(atype, AgentType):
                    key = atype.name
                else:
                    key = str(atype)
                agent_type_counts[key] = agent_type_counts.get(key, 0) + 1

        return {
            "index": scene_idx,
            "name": scene.name,
            "duration_seconds": scene.length_timesteps * scene.dt,
            "num_timesteps": scene.length_timesteps,
            "timestep_duration": scene.dt,
            "num_agents": len(scene.agent_presence[0]) if scene.agent_presence else 0,
            "agent_type_counts": agent_type_counts,
        }


def convert_interhub_scene_to_rds_hq(
    cache_path: str,
    scene_idx: int,
    time_start: float,
    time_end: float,
    output_dir: str,
    dataset_name: str = "interaction_multi",
    **kwargs,
) -> Path:
    """
    简单封装：一行命令从 InterHub 场景转到 RDS-HQ。
    """
    bridge = InterHubToTeraSimBridge(cache_path, dataset_name)
    return bridge.generate_rds_hq_from_scene(
        scene_idx=scene_idx,
        time_start=time_start,
        time_end=time_end,
        output_dir=output_dir,
        **kwargs,
    )
